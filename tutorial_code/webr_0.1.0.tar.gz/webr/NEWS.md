# webr version 0.1.0
=====================
(18-Apr-2018)

* new function plot.htest() added

* new function rens.text() and cox.stuart.test() added



